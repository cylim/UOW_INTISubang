//Author	:Lim Chee Yeong
//Student ID: J14016414(INTI) or 4933643(UOW)
//Class		:CSCI124
//Lab Task	:5
//Date		:September 18th, 2014
//This program is a mini game to guess the letter in a word from wordlist.

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <cctype>
using namespace std;

int main(){
	//For testing purpose, use the file directly
	ifstream in("hiddenWords.txt");
	//char file[30];
	//cout << "Enter filename: ";
	//cin >> file;
	//ifstream in(file);

	int total;
	char ** wordList = new char*[total];
	in >> total;
	for(int x=0; x< total; x++){
		wordList[x] = new char[21];
		in >> wordList[x];
	}
	in.close();
	//check the correctness of data from file
	//cout << total << endl;
	//for(int i=0;i<total;i++){
	//	cout << wordList[i] << endl;
	//}
	int random = rand() % total+1;
	int length = strlen(wordList[random]);
	char secretWord[length];
	int count = 0;
	char userInput;
	while(true){
		count+=1;
		cout << "Guess letter in the secret word: " << secretWord << endl;
		cout << "Enter letter(* to quit): ";
		cin >> userInput;
		for(int i=0; i<total; i++){
			if (userInput == wordList[random][i]){
				secretWord[i] = wordList[random][i];
			}
		}
		if(secretWord == wordList[random]){
			cout << "Good Job!" << endl;
			cout << "You have guessed the word " << secretWord 
				<< " in " << count << " tries." << endl;
			userInput = '*';
		}

		if (userInput == '*'){
			cout << "Would you like to play the game again(Y/N)";
			cin >> userInput;
			switch(userInput){
				case 'Y':
				case 'y':
					random = rand() % total+1;
					length = strlen(wordList[random]);
					secretWord[length];
					count = 0;
					break;
				default:
					cout << "Wrong Input, ";
				case 'N':
				case 'n':
					cout << "Thank you for playing the game!" << endl;
					return 0;
			}	
		}
	}
}