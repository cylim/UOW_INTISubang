#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;

void readMaster();
void readTransaction();
void calSales();
void updateMaster();
void displayMaster();

struct nameList{
		int sid;
		char firstName[10];
		char midName[10];
		char lastName[10];
		float sales;
};

int main(){
	nameList salesPerson[10];

	readMaster();
	readTransaction();
	updateMaster();
}

void readMaster(){
	char masterFile[50];
	cout << "Enter master file name: " << endl;
	cin >> masterFile;
	ifstream master;
	master.open(masterFile, ios::in);

	master.close();
}

void readTransaction(){
	char transFile[50];
	cout << "Enter transaction file name: " << endl;
	cin >> transFile;
	ifstream trans(transFile);

	trans.close();
}

void calSales(){

}

void updateMaster(){
	char masterFile[50];
	cout << "Enter new master file name: " << endl;
	cin >> masterFile;
	ofstream newMaster;
	newMaster.open(masterFile);

	newMaster.close();

}

void displayMaster(){

}