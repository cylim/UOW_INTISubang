#include <iostream>
#include <fstream>
using namespace std;

struct Cust{
	int id;
	char firstName[51];
	char lastName[51];
	char contact[21];
};

int checkTotal(char[]);
void read(Cust*, char[]);
void sort(Cust*, int);
void search();