#include "customer.h"

int checkTotal(char file[]){
	ifstream bin(file, ios::binary | ios::ate);
	if(!bin){
		cout << "The file not found!" << endl;
		return -1;
	}
	int location = bin.tellg();
	if(location % sizeof(Cust) > 0){
		cout << "The size is not accurate!" << endl;
		return -1;
	}
	return location / sizeof(Cust);
}

void read(Cust *cust, char file[]){
	int x=0;
	ifstream bin(file, ios::binary);
	bin.seekg(0, ios::beg);
	while(bin.good()){
		if(!bin.eof()){
			bin.read((char*)&cust[x], sizeof(Cust));
			x+=1;
			//cout << x << endl; //to see the location of storage
		}
	}
}

void sort(Cust *cust, int total){
	for(int c = 1; c < total; c++){
		Cust temp = cust[c];
		for(int j = c; j>=0; j--){
			if (temp.id < cust[j].id){
				cust[j+1] = cust[j];
			}
		}
		cust[j+1] = temp;
	}
}

void search(){
	
}