#include "customer.h"

int main(){
	Cust *cust;
	// char file[10];
	// cout << "Enter filename: ";
	// cin >> file;
	//For testing purpoose,
	char file[] = "cust.dat";

	int total = checkTotal(file);
	//cout << total << endl; // see the value of total
	//if there is an error in the checkTotal function, terminate the program
	if(total == -1){
		return 0;
	}
	cust = new Cust[total];

	read(cust, file);
	cout << "The data have successfully read." << endl;
	//For checking purposes,
	// for(int i=0; i< total; i++){
	// 	cout << "ID: " << cust[i].id << endl
	// 		<< "Name: " << cust[i].firstName << " " << cust[i].lastName << endl
	// 		<< "Contact: " << cust[i].contact << endl;
	// }

	sort(cust, total);
	//For checking purposes,
	for(int i=0; i< total; i++){
		cout << "ID: " << cust[i].id << endl
			<< "Name: " << cust[i].firstName << " " << cust[i].lastName << endl
			<< "Contact: " << cust[i].contact << endl;
	}

	search();
}