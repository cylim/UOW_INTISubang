struct ChemicalElement{
	int atomicNumber;
	char name[100];
	char symbol[3];
	float mass;
};

int readToBinary(ChemicalElement[]);