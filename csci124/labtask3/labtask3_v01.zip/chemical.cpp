#include "chemical.h"
using namespace std;

void search(ChemicalElement list[], int num){
	
}

void greaterMass(ChemicalElement list[], int num){
	
}

void rangeNumber(ChemicalElement list[], int num){
	
}