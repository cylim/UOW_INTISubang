//Author	:Lim Chee Yeong
//Student ID: J14016414(INTI) or 4933643(UOW)
//Class		:CSCI204
//Assignment:1
//This program read files into binary
//and provide various search funtion to search the chemical elements

#include <iostream>
#include "fileOperation.h"
#include "chemical.h"
using namespace std;

int main(){
	ChemicalElement list[150];
	int num;
	char input;
	num = readToBinary(list);
	if(num == -1){
		return 0;
	}
	cout << "Search Method: " << endl;
	cout << "(N)ame or symbol, (G)reater, (R)ange, (E)xit" << endl;
	cout << "Options: ";
	cin >> input;
	switch(input){
		case 'N':
		case 'n':
			search(list, num);
			break;
		case 'G':
		case 'g':
			greaterMass(list, num);
			break;
		case 'R':
		case 'r':
			rangeNumber(list, num);
			break;
		default:
			cout << "Wrong input, ";
		case 'E':
		case 'e':
			cout << "Program terminated!" << endl;
 			return 0;
	}	
}