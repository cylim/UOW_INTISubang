#include <iostream>
#include <fstream>
#include <cstring>
#include "fileOperation.h"
using namespace std;

int readToBinary(ChemicalElement list[]){
	int num=0;
	//For testing purpose, use file below,
	char file[] = "chemicalElements.txt";
	//char file[50];
	//cout << "Please enter filename: ";
	//cin >>file;
	ifstream read(file);
	//check file, if the file is not available
	if(!read){
		cout << "File not found!" << endl;
		// return value -1 to main(), so that main can return to 0
		return -1;
	}
	while(!read.eof()){
		read >> list[num].mass;
		read >> list[num].name;
		read >> list[num].symbol;
		read >> list[num].atomicNumber;
		num++;
	}
	read.close();
	//For testing purpose, check the total line and output of the struct
	//cout << num;
	//for(int i =0; i < num; i++){
	//	cout << list[i].mass << "\t" << list[i].name << "\t" << list[i].symbol << "\t" << list[i].atomicNumber << "\n";
	//}

	//cout << "Enter a filename for binary output: ";
	//cin >> file
	//ofstream out(file, ios::out | ios::binary);
	//For testing purpose, use example.bin
	ofstream out("example.bin", ios::out | ios::binary);
	for(int i=0; i<num; i++){
		out.write((char*)list[i].name, strlen(list[i].name));
	}
	return num;
}