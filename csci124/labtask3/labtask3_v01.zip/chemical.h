extern struct ChemicalElement list[];

void search(ChemicalElement[], int);
void greaterMass(ChemicalElement[], int);
void rangeNumber(ChemicalElement[], int);