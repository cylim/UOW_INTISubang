#include <iostream>
#include <fstream>
#include <cstring>
#include "xmlAddress.h"
using namespace std;

void readAddress(char file[], list people[]){
	bool notXML = false;
	ifstream read(file);

	for(int i= strlen(file-5);i< strlen(file);i++){

	}

	if(!file){
		cout << "File not found!" << endl;
		terminate();
	}else if(notXML == true){
		cout << "File is not in XML format" << endl;
		terminate();
	}

	
	read.close();
}

void searchPostcode(){


}

void serachPlace(){

}