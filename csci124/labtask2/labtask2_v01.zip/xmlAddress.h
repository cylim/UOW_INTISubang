struct list{
	char name[50];
	char street[50];
	char city[50];
	char postcode[50];
};

void readAddress(char[], list[]);
void searchPostcode();
void searchPlace();

