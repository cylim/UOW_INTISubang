#include <iostream>
#include "xmlAddress.h"
using namespace std;

int main(){
	list people[100];
	char file[50];
	cout << "Please enter filename: ";
	cin >>file;

	readAddress(file, people);
}