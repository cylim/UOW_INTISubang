struct Rainfall{
	char month[10];
	int daysWithRain;
	float avgRainfall;
};

int setRainfallData(Rainfall[]);
void displayRainfall();
void displayDay();
void searchRecord();
void searchMonth();