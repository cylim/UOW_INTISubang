//Author	:Lim Chee Yeong
//Student ID: J14016414(INTI) or 4933643(UOW)
//Class		:CSCI124
//Lab Task	:4
//Date		:September 4th, 2014
//This program prompt user to input data, and save it into binary file.

#include <fstream>
#include <iostream>
#include <cstring>
#include "rainfallData.h"
using namespace std;

int setRainfallData(Rainfall data[]){
	char check, month[10];
	bool validate = false;
	int total=0;
	int *i = &total;
	do{
		cout << "Add Rainfall Record," << endl;
		while(validate == false){
			cout <<	"Month: ";
			cin >> month;
			validate = true;
			for(int x=0; x<total; x+=1){
				if(strcmp(data[x].month, month) == 0){
					cout << "Month exists. please try again," << endl;
					validate = false;
					break;	
				}
			}
			if(validate == true){
				strcpy(data[*i].month, month);
			}
		}
		cout << "Days with rain: ";
		cin >> data[*i].daysWithRain;
		cout << "Average Rainfall: ";
		cin >> data[*i].avgRainfall;
		total+=1;
		cout << "Continue add record? (Y/N)";
		cin >> check;
	}while(check == 'y' || check == 'y');
	return total;
}

void displayRainfall(){

}
void displayDay(){

}
void searchRecord(){

}
void searchMonth(){

}