//Author	:Lim Chee Yeong
//Student ID: J14016414(INTI) or 4933643(UOW)
//Class		:CSCI204
//Lab task	:6 - 1
//Date		:October 7th, 2014
//This console program is about dynamic classes object allocation, inheritance and polymorphism.
#include <iostream>
using namespace std;

class Ship{
protected:
	string name, year;
public:
	Ship(string = "None", string = "None");
	inline void setName(string name){ this->name = name; }
	inline void setYear(string year){ this->year = year; }
	inline string getName(){ return name; }
	inline string getYear(){ return year; }
	virtual void print();
};
class CruiseShip: public Ship{
	int passenger;
public:
	CruiseShip(string = "None", string = "None", int = 0);
	inline void setPassenger(int passenger){ this->passenger = passenger; }
	inline int getPassenger(){ return passenger; }
	virtual void print();
};
class CargoShip: public Ship{
	float capacity;
public:
	CargoShip(string = "None", string = "None", float = 0);
	inline void setCapacity(float capacity){ this->capacity = capacity; }
	inline float getCapacity(){ return capacity; }
	virtual void print();
};

Ship::Ship(string name, string year){
	this->name = name;
	this->year = year;
}
void Ship::print(){
	cout << endl << "Ship Information," << endl;
	cout << "Name\t: " << name << endl
		<<"Year\t: " << year << endl;
}

CruiseShip::CruiseShip(string name, string year, int passenger)
:Ship(name, year){
	this->passenger = passenger;
}
void CruiseShip::print(){
	cout << endl << "Cruise ship Information," << endl;
	cout << "Name\t: " << name << endl
		<< "Passenger: " << passenger << " people" << endl; 
}

CargoShip::CargoShip(string name, string year, float capacity)
:Ship(name, year){
	this->capacity = capacity;
}
void CargoShip::print(){
	cout << endl << "Cargo ship Information," << endl;
	cout << "Name\t: " << name << endl
		<< "Capacity: " << capacity << " ton" << endl;
}

int main(){
	Ship *pointerShip[3];
	for(int x=1; x<4; x++){
		if(x%10 == 1){
			pointerShip[x-1] = new Ship("SHIP", "1994");
		} else if(x%10 == 2){
			pointerShip[x-1] = new CruiseShip("Cruise", "1990", 250);
		} else if(x%10 == 3){
			pointerShip[x-1] = new CargoShip("Cargo", "1975", 2500);
		}
	}

	for(int x=0; x<3; x++){
		pointerShip[x]->print();
	}
}