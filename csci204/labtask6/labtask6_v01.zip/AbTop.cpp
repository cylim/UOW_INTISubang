//Author	:Lim Chee Yeong
//Student ID: J14016414(INTI) or 4933643(UOW)
//Class		:CSCI204
//Lab task	:6 - 2
//Date		:October 7th, 2014
//This program built a better understanding in inheritance and the differences between initialize using function or constructor
#include <iostream>
using namespace std;

class A{
	string AFood;
public:
	virtual void abstract() = 0;
	inline void setAFood(string food){ AFood = food; }
	void output();
};
class B: public A{
	string BFood;
public:
	B();
	void output();
};
class C: public B{
	string CFood;
public:
	C();
	void output();
};

A::output(){
	
}

B::B(){

}
void B::output(){

}

C::C(){

}
void C::output(){

}

int main(){

}