//Author	:Lim Chee Yeong
//Student ID: J14016414(INTI) or 4933643(UOW)
//Class		:CSCI204
//Lab task	:6 - 3
//Date		:October 7th, 2014
//This program used typeid function to demonstrate five different data types
#include <iostream>
using namespace std;