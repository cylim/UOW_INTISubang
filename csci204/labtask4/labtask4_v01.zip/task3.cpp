//Author	:Lim Chee Yeong
//Student ID: J14016414(INTI) or 4933643(UOW)
//Class		:CSCI204
//Lab task	:4 -3
//Date		:September 9th, 2014
//This program makes update student data in particular subject easier
