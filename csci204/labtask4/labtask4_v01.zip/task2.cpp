//Author	:Lim Chee Yeong
//Student ID: J14016414(INTI) or 4933643(UOW)
//Class		:CSCI204
//Lab task	:4 - 2
//Date		:September 9th, 2014
//This program make use of operator overloading
#include <iostream>
using namespace std;

class Length{
	friend ostream& operator<<(ostream&, const Length&);
	friend istream& operator>>(istream&, Length&);
private:
	int meter, centimeter, millimeter;
public:
	bool operator<(Length&);
	Length operator+(Length&);
};
bool Length::operator<(Length& l){
	if (meter < l.meter){
		return true;
	}
	else if(meter == l.meter){
		if(centimeter < l.centimeter){
			return true;
		}
		else if (centimeter == l.centimeter){
			if (millimeter < l.millimeter){
				return true;
			}
		}
	} 
	return false;
}
Length Length::operator+(Length &l){
 	Length total;
 	total.millimeter = millimeter + l.millimeter;
 	total.centimeter = centimeter + l.centimeter;
 	total.meter = meter + l.meter;
 	
 	total.centimeter += total.millimeter/10;
 	total.millimeter %= 10;
 	total.meter += total.centimeter/100;
 	total.centimeter %= 100;
 	return total;
}
ostream& operator<<(ostream& out, const Length &l){
	out << "Meter: " << l.meter << endl
		<< "Centimeter: " << l.centimeter << endl
		<< "millimeter: " << l.millimeter << endl;
	return out;
}
istream& operator>>(istream& in, Length &l){
	cout << "Enter Meter: ";
	in >> l.meter;
	cout << "Enter Centimeter: ";
	in >> l.centimeter;
	cout << "Enter millimeter: ";
	in >> l.millimeter;
	return in;
}
int main(){
	Length a,b;
	cout << "Enter length for object A," << endl;
	cin >> a;
	cout << "Enter length for object B," << endl;
	cin >> b;
	if (a < b){
		cout << "Object A shorter than Object B, A+B," << endl;
		a = a + b;
		cout << a;
	}
}