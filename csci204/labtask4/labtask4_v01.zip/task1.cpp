//Author	:Lim Chee Yeong
//Student ID: J14016414(INTI) or 4933643(UOW)
//Class		:CSCI204
//Lab task	:4 - 1
//Date		:September 9th, 2014
//This program use friend function to show the details of two class.

#include <iostream>
using namespace std;

class HotelRoom;
class Guest{
	friend void display(Guest, HotelRoom);
private:
	string name;
	string ID;
public:
	Guest(string, string);
	inline void setName(string name){ this->name = name;}
	inline void setID(string ID){ this->ID = ID; }
	inline string getName(){ return name; }
	inline string getID(){ return ID;}
};
Guest::Guest(string name, string ID){
	setName(name);
	setID(ID);
}

class HotelRoom{
	friend void display(Guest, HotelRoom);
private:
	string name;
	string room;
	float rate;
public:
	HotelRoom(string, string, float);
	inline void setName(string name){ this->name = name; }
	inline void setRoom(string room){ this->room = room; }
	inline void setRate(float rate){ this->rate = rate; }
	inline string getName(){ return name; }
	inline string getRoom(){ return room; }
	inline float getRate(){ return rate; }
};
HotelRoom::HotelRoom(string name, string room, float rate){
	setName(name);
	setRoom(room);
	setRate(rate);
}

void display(Guest g, HotelRoom h){
	cout << "Guest Details," << endl
		<< "Name\t:" << g.getName() << endl
		<< "ID\t:" << g.getID() << endl;
	cout << "Room Details," << endl
		<< "Name\t:" << h.getName() << endl
		<< "Room\t:" << h.getRoom() << endl
		<< "Rate\t:RM" << h.getRate() << endl;
}

int main(){
	Guest g("Byron Lim", "J14016414");
	HotelRoom h("ABC Hotel", "F402", 98.8);
	display(g,h);
}