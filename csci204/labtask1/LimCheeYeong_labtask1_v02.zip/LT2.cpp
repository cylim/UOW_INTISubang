//Writen by Lim Chee Yeong INTI: J14016414 or UOW: 4933643

#include <iostream>
#include <string>
using namespace std;

char tableProperties(int&, int&, char[], char);
float calculatePrice(int, int, char);
void displayPrice(float, int, int, char[], char);

int main(){
	int chairs, tableSurface;
	char chairColor[10], woodType;
	float total;
	woodType = tableProperties(chairs, tableSurface, chairColor, woodType);
	total = calculatePrice(chairs, tableSurface, woodType);
	displayPrice(total, chairs, tableSurface, chairColor, woodType);
}

char tableProperties(int &chairs, int &tableSurface, char chairColor[], char woodType){
	cout << "Enter the number of chairs for table: ";
	cin >> chairs;
	cout << "Enter the colour of the cushions: ";
	cin >> chairColor;
	cout << "Enter the surface area of the table: ";
	cin >> tableSurface;
	for(;;){
		cout << "Enter the type of wood - m for mahogany, o for oak, or p for pine: ";
		cin >> woodType;
		switch(woodType){
			case 'M':
			case 'm':
				return 'm';
			case 'o':
			case 'O':
				return 'o';
			case 'p':
			case 'P':
				return 'p';
			default:
				cout << "Error input, please try again." <<endl;
		}

	}
}

float calculatePrice(int n, int s, char woodType){
	int x;
	switch(woodType){
		case 'm': 
			x = 200;
			break;
		case 'o':
			x = 150;
			break;
		case 'p':
			x = 95;
			break;
	}
	return (x * (s + 0.5 * n));
}

void displayPrice(float total, int chairs, int tableSurface, char chairColor[], char woodType){
	string woodType2;
	if (woodType == 'm')
		woodType2 = "mahogany";
	if (woodType == 'o')
		woodType2 = "oak";
	if (woodType == 'p')
		woodType2 = "pine";
	cout << "You have chosen a " << woodType2 << " table with: " << endl
		<< "Surface area " << tableSurface << " and " << chairs << " chairs with " << chairColor << " cushions!" << endl
		<< "Price is $" << total <<endl;
}