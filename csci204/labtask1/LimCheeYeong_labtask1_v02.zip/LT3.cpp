//Writen by Lim Chee Yeong INTI: J14016414 or UOW: 4933643

#include <iostream>
#include <string>
#include <cstring>

using namespace std;

int main(){
	string password;
	char pass[100];
	int lower=0, upper=0, digit=0;
	cout << "Enter password: ";
	cin >> password;
	strcpy(pass, password.c_str());

	for(int i = 0; i< password.length(); i++){
		if(pass[i] <= 'Z' && pass[i] >= 'A')
			upper++;
		if(pass[i] <= 'z' && pass[i] >= 'a')
			lower++;
		if(pass[i] <= '9' && pass[i] >= '0')
			digit++;
	}

	if(password.length() < 6){
		cout << "Your password must have at least SIX characters." << endl;
	}
	else if(upper < 1){
		cout << "Your password must contain at least ONE UPPERCASE letter." << endl;
	}
	else if(lower < 1){
		cout << "Your password must contain at least ONE LOWERCASE letter." << endl;
	}
	else if(digit < 1){
		 cout << "Your password must contain at least ONE DIGIT." << endl;
	}
	else	
		cout << "Password Accepted." << endl;
}