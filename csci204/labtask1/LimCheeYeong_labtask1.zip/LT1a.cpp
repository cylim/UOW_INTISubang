//Writen by Lim Chee Yeong INTI: J14016414 or UOW: 4933643

#include <iostream>
using namespace std;

int main(){
	int num[3];
	cout << "input numbers, " << endl;
	for(int i= 0; i<3; i++)
		cin >> num[i];
	cout << "the numbers are, "<< endl;
	for(int i= 0; i<3; i++)
		cout << num[i] << endl;
}