//Writen by Lim Chee Yeong INTI: J14016414 or UOW: 4933643

#include <iostream>
using namespace std;

void tableProperties(int&, int&, char[], char[]);
float calculatePrice(int&, int&, char[]);
void displayPrice(float, int, int, char[], char[]);

int main(){
	int chairs, tableSurface;
	char chairColor[10], woodType[10];
	float total;
	tableProperties(chairs, tableSurface, chairColor, woodType);
	total = calculatePrice(chairs, tableSurface, woodType);
	displayPrice(total, chairs, tableSurface, chairColor, woodType);
}

char tableProperties(int &chairs, int &tableSurface, char chairColor[], char woodType){
	char woodType2;
	cout << "Enter the number of chairs for table: ";
	cin >> chairs;
	cout << "Enter the colour of the cushions: ";
	cin >> chairColor;
	cout << "Enter the surface area of the table: ";
	cin >> tableSurface;
	for(;;){
		cout << "Enter the type of wood -m for mahogany, o for oak, or p for pine: ";
		cin >> woodType2;
		switch(woodType2){
			case 'M':
			case 'm':
				woodType = "mahogany";
			case 'o':
			case 'O':
				woodType = "oak";
			case 'p':
			case 'P':
				woodType = "pine";
			default:
				continue;
		}

	}
}

float calculatePrice(int n, int s, char woodType[]){
	int x;
	switch(woodType[0]){
		case 'm': 
			x = 200;
			break;
		case 'o':
			x = 150;
			break;
		case 'p':
			x = 95;
			break;
	}
	return (float)x * (s + 0.5*n);
}

void displayPrice(float total, int chairs, int tableSurface, char chairColor[], char woodType[]){
	cout << "You have chosen a " << woodType << "table with: " << endl
		<< "Surface area: " << tableSurface << "and " << chairs << "chairs with " << chairColor << "cushions!" << endl
		<< "Price is $" << total;
}