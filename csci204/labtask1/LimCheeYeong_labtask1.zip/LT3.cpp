//Writen by Lim Chee Yeong INTI: J14016414 or UOW: 4933643

#include <iostream>
using namespace std

int main(){
	char[] password = cin << "Enter Password: "
	verifyPassword(password[])
}

void verifyPassword(char[] password){

}