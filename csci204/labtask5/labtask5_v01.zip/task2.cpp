class Payment{
	float payment;
public:
	Payment();
	Payment(float);
	void setField(float);
	void paymentDetails();

};

class CashPayment: public Payment{
	float balance;
public:
	CashPayment();
	CashPayment(float, float)
	void setField(float, float);
	void paymentDetails();
};

class CreditCardPayment: public Payment{
	string name;
	string expire;
	long number;
public:
	CreditCardPayment();
	CreditCardPayment(float, string, string, long);
	void setField(float, string, string, long);
	void paymentDetails();
};


int main(){

}