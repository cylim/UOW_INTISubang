#include <iostream>
using namespace std;

class Publication{
	string title;
	float price;
public:
	Publication();
	void getData();
	void showData();
};
class Book: public Publication{
	int page;
public:
	Book();
	void getData();
	void showData();
};
class Disk: public Publication{
	char type;
public:
	Disk();
	void getData();
	void showData();
};

Publication::Publication(){
	title = "";
	price = 0;
}
void Publication::getData(){
	cout << "Title: ";
	cin >> title;
	cout << "Price: ";
	cin >> price;
}
void Publication::showData(){
	cout << "Title\t:" << title << endl;
	cout << "Price\t:" << price << endl;
}

Book::Book(){
	page = 0;
}
void Book::getData(){
	cout << "Book Information," << endl;
	Publication::getData();
	cout << "Page: ";
	cin >> page;
}
void Book::showData(){
	Publication::showData();
	cout << "Page\t:" << page << endl;
}

Disk::Disk(){
	char type;
}
void Disk::getData(){
	cout << "Disk Information," << endl;
	Publication::getData();
	cout << "Disk type(C = CD/ D =DVD): ";
	cin >> type;
}
void Disk::showData(){
	Publication::showData();
	switch(type){
		case 'c':
		case 'C':
			cout << "Type\t:CD" << endl;
			break;
		case 'd':
		case 'D':
			cout << "Type\t:DVD" << endl;
			break;
		default:
			cout << "Type\t:invalid";
	}
}


int main(){
	Book book;
	Disk disk;

	book.getData();
	disk.getData();

	cout << "Book Information," << endl;
	book.showData();
	cout << "Disk Information," << endl;
	disk.showData();
}