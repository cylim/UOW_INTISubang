//Writen by Lim Chee Yeong INTI: J14016414 or UOW: 4933643

#include <iostream>
using namespace std;

class ClubMember{
	string clubName;
	string memberName;
	int memberID;
	const static int fee;

public:
	void setClubName(string);
	void setMemberName(string);
	void setMemberID(int);
	void display();
};
//implementation section:
void ClubMember::setClubName(string name){
	clubName = name;
}

void ClubMember::setMemberName(string name){		
	memberName = name;
}

void ClubMember::setMemberID(int id){
	memberID = id;
}

const int ClubMember::fee = 25;

void ClubMember::display(){
	cout << "Club Name: " << clubName << endl
		<< "Member Name: " << memberName << endl
		<< "Member ID: " << memberID << endl
		<< "Fees: RM" << fee << endl;
}

int main(){
	ClubMember member;
	member.setClubName("Googley");
	member.setMemberName("Googler");
	member.setMemberID(666);
	member.display();
}