//Writen by Lim Chee Yeong INTI: J14016414 or UOW: 4933643

#include <iostream>
using namespace std;

class Temperature{
	float kelvin;

public:
	void setTempKelvin(float);
	void setTempFahrenheit(float);
	void setTempCelsius(float);
	float getTempKelvin();
	float getTempFahrenheit();
	float getTempCelsius();
	void display();
};
//implementation class function
	void Temperature::setTempKelvin(float temp){
		kelvin = temp;
	}
	void Temperature::setTempFahrenheit(float temp){
		kelvin = ((temp-32)*5/9) + 273.15;
	}
	void Temperature::setTempCelsius(float temp){
		kelvin = temp + 273.15;
	}
	float Temperature::getTempKelvin(){
		return kelvin;
	}
	float Temperature::getTempFahrenheit(){
		return ((kelvin - 273.15) * 9 / 5) + 32;
	}
	float Temperature::getTempCelsius(){
		return kelvin - 273.15;
	}
	void Temperature::display(){
		cout << "Kelvin: " << getTempKelvin() << endl
			<< "Fahrenheit: " << getTempFahrenheit() << endl
			<< "Celsius: " << getTempCelsius() << endl;
	}

int main(){
	Temperature convertTemp;
	char type;
	float temp;
	cout << "Please input temperature: ";
	cin >> temp;
	cout << "k: Kelvin, f: Fahrenheit, c:Celsius\n"
		<<	"Please choose Temperature input type: ";
	cin >> type;
	switch(type){
		case 'k':
		case 'K':
			convertTemp.setTempKelvin(temp);
			break;
		case 'f':
		case 'F':
			convertTemp.setTempFahrenheit(temp);
			break;
		case 'c':
		case 'C':
			convertTemp.setTempCelsius(temp);
			break;
		default:
			cout << "Wrong type!";
			return 0;
	}
	convertTemp.display();
 }