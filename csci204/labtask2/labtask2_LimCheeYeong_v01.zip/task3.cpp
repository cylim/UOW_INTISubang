//Writen by Lim Chee Yeong INTI: J14016414 or UOW: 4933643

#include <iostream>
using namespace std;

class RentalCar{
	long int regNum;
	string model;
	string type;
	int engineNum;
	int chasisNum;
	const static rental[][];
public:
	void setRental();
	void setAll();

};
//implementation 

int main(){

}