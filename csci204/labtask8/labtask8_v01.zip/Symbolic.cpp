//Author	: Lim Chee Yeong
//Student ID: J14016414(INTI) or 4933643(UOW)
//Class		: CSCI204
//Task		: 8 -2
//Date		: October 28th, 2014
//
#include <iostream>
using namespace std;

template <class T>
void addSymbol(T input, int num, char symbol){
	for(int x=0; x<num; x++){
		cout << symbol;
	}
	cout << input;
	for(int x=0;x<num;x++){
		cout << symbol;
	}
	cout << endl;
}

int main(){
	addSymbol('A', 2, 'x');
	addSymbol(47, 3, '*');
	addSymbol(39.25, 3, '0');
	addSymbol("Bob", 4, 'a');
}