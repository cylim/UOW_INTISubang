//Author	: Lim Chee Yeong
//Student ID: J14016414(INTI) or 4933643(UOW)
//Class		: CSCI204
//Task		: 8 - 3
//Date		: October 28th, 2014
//
#include <iostream>

int main(){
	
}