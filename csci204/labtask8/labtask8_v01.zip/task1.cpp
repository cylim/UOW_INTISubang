//Author	: Lim Chee Yeong
//Student ID: J14016414(INTI) or 4933643(UOW)
//Class		: CSCI204
//Task		: 8 -1
//Date		: October 28th, 2014
//
#include <iostream>
#include <fstream>
#include <exception>
using namespace std;

class Logger{
	static Logger* instance;
protected:
	Logger(){}
public:
	static Logger* Instance();
	static void log(int, string, int);
	static void stopLogger();
};

Logger* Logger::instance = 0;
Logger* Logger::Instance(){
	if( instance == 0)
		instance = new Logger;
	else
		throw((char*)&"Unable to initialize the logger");
	return instance;
}
void Logger::log(int code, string message, int level){
	ofstream write("log.txt", ios::app);
	write << code << " " << message << " " << level << '\n';
	write.close();

}
void Logger::stopLogger(){
	delete instance;
	instance=0;
}

int main(){
	int input;
	while(true){
		cout << "1. Create Log\n"
			<< "2. Log Message\n"
			<< "3. Delete Log\n"
			<< "0. Exit\n";
		cout << "Option: ";
		cin >> input;

		int code, level;
		string message;
		Logger *ptr;
		switch(input){
			case 1:
				try{
					ptr = Logger::Instance();
				}
				catch(char* e){
					cout << "Issue: " << e << endl;
					cout << "Please stop previous logger before create a new one."<< endl;
				}
				break;
			case 2:
				cout << "Code: ";
				cin >> code;
				cout << "Message: ";
				cin.ignore();
				getline(cin, message);
				cout << "Level: ";
				cin >> level;
				ptr->log(code, message, level);
				break;
			case 3:
				ptr->stopLogger();
				break;
			case 0:
				cout << "System Terminated." << endl;
				return 0;
			default:
				cout << "Wrong input, please try again." << endl;
		}
	}
	
}